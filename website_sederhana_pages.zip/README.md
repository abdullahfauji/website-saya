# Website Sederhana untuk GitHub Pages

**Cara cepat:**
1) Unggah semua file ini ke repo GitHub Anda.
2) Buka **Settings → Pages**.
3) Pilih **Source: Deploy from a branch**.
4) Pilih **Branch: main** dan **Folder: /** (root), lalu **Save**.
5) Tunggu 1–10 menit. Alamat: `https://username.github.io/nama-repo/`.

> File `.nojekyll` memastikan GitHub Pages tidak memproses Jekyll sehingga folder/asset tertentu tidak diabaikan.